function openWishlist() { window.location.href = 'wishlist.html'; }
function openCart() { window.location.href = 'cart.html'; }
function checkout() { alert('Proceeding to Payment'); }